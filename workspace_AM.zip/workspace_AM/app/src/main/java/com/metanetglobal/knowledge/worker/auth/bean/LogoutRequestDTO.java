package com.metanetglobal.knowledge.worker.auth.bean;

import com.metanetglobal.knowledge.worker.common.bean.BaseRequestDTO;

/**
 * Logout Request DTO
 *
 * @author      namki.an
 * @version     1.0.0
 * @see         BaseRequestDTO
 */
public class LogoutRequestDTO extends BaseRequestDTO {
}
