package com.metanetglobal.knowledge.worker.schedule.otto_interfaces;

/**
 * Event of Update Schedule for OTTO
 *
 * @author      namki.an
 * @version     1.0.0
 */
public class Event_UpdateSchedule {
}
