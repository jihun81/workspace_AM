package com.metanetglobal.knowledge.worker.common.bean;

/**
 * Base Request DTO
 *
 * 모든 Request DTO 들은 이 Class 를 상속받는다.
 *
 * @author      namki.an
 * @version     1.0.0
 */
public class BaseRequestDTO {

}
