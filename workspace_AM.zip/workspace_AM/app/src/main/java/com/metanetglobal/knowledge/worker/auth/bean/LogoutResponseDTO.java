package com.metanetglobal.knowledge.worker.auth.bean;

import com.metanetglobal.knowledge.worker.common.bean.BaseResponseDTO;

/**
 * Logout Response DTO
 *
 * @author      namki.an
 * @version     1.0.0
 * @see         BaseResponseDTO
 */
public class LogoutResponseDTO extends BaseResponseDTO {
}
